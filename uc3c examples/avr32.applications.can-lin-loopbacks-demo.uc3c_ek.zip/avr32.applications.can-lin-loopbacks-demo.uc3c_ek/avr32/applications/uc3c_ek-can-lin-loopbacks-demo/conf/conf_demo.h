/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief UC3C-EK CAN and LIN Loopbacks configuration file.
 *
 *
 * - Compiler:           IAR EWAVR32 and GNU GCC for AVR32
 * - Supported devices:  All AVR32 with a external bus interface.
 * - AppNote:
 *
 * \author               Atmel Corporation: http://www.atmel.com \n
 *                       Support and FAQ: http://support.atmel.no/
 *
 *****************************************************************************/

/*! \page License
 * Copyright (c) 2009 Atmel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of ATMEL may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. ATMEL grants developer a non-exclusive, limited license to use the Software
 * as a development platform solely in connection with an Atmel AVR product
 * ("Atmel Product").
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */

#ifndef _CONF_DEMO_H_
#define _CONF_DEMO_H_

#include "board.h"
#include "conf_et024006dhu.h"

/*! \name System Clock Frequencies
 */
//! @{
#define FMCK_HZ   FOSC0
#define FCPU_HZ   FMCK_HZ
#define FHSB_HZ   FCPU_HZ
#define FPBA_HZ   FMCK_HZ
#define FPBB_HZ   FMCK_HZ
//! @}

#define BUFFER_LENGTH		256

#define DEFAULT_SCREEN_UPDATE_FS_MS   100

#define NUMBER_OF_INPUTS_ADC_SEQ0   1 
#define INPUT1_ADC_CHANNEL          5
#define INPUT1_ADC_INP              AVR32_ADCIFA_INP_ADCIN5
#define INPUT1_ADC_INN              AVR32_ADCIFA_INN_GNDANA
#define INPUT1_ADC_PIN              AVR32_ADCIN5_PIN
#define INPUT1_ADC_FUNCTION         AVR32_ADCIN5_FUNCTION

#define NUMBER_OF_INPUTS_ADC_SEQ1   1
#define INPUT2_ADC_CHANNEL          14
#define INPUT2_ADC_INP              AVR32_ADCIFA_INP_GNDANA
#define INPUT2_ADC_INN              AVR32_ADCIFA_INN_ADCIN14
#define INPUT2_ADC_PIN              AVR32_ADCIN14_PIN
#define INPUT2_ADC_FUNCTION         AVR32_ADCIN14_FUNCTION

//#define BUTTON_CONTROL

#endif //_CONF_DEMO_H_
