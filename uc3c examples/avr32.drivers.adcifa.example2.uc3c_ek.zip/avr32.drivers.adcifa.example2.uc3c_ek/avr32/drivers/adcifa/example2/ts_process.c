/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief Tempsensor Compensation Process for AVR UC3C.
 *
 *
 * - Compiler:           IAR EWAVR32 and GNU GCC for AVR UC3C
 * - Supported devices:  All AVR UC3C devices with an ADCIFA
 * - AppNote:
 *
 * \author               Atmel Corporation: http://www.atmel.com \n
 *                       Support and FAQ: http://support.atmel.no/
 *
 *****************************************************************************/

/*! \page License
 * Copyright (c) 2009 Atmel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an Atmel
 * AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 *
 */
#include <avr32/io.h>
#include "compiler.h"
#if defined (__GNUC__)
#  include "intc.h"
#endif

#include "board.h"
#include "tc.h"
#include "gpio.h"
#include "adcifa.h"
#include "scif_uc3c.h"

#include "ts_process.h"

// Static Variable for pba_hz
static unsigned long g_pba_hz;

// To specify we have to start Temp Sensor Conversion a new time
volatile static int ts_start_read = 1;
volatile static S32 aref_recalc = 0;

volatile U32 tc_tick = 0;

static S32 ts_update_temperature(ts_opt_t ts_opt);

/*! \brief TC interrupt.
 */
#if defined (__GNUC__)
__attribute__((__interrupt__))
#elif defined (__ICCAVR32__)
#pragma handler = TC_IRQ_GROUP, 1
__interrupt
#endif
static void ts_irq(void)
{
  // Increment the ms seconds counter
  tc_tick++;

  // Clear the interrupt flag. This is a side effect of reading the TC SR.
  tc_read_sr(TC_INSTANCE, TC_CHANNEL);

  // Specify that an interrupt has been raised.
  ts_start_read = 1;
}

S32 ts_update_temperature(ts_opt_t ts_opt)
{  
   // Declare variable
  S16 adc_values[1];
  S32 aref_recalc;
  volatile avr32_adcifa_t *adcifa = &AVR32_ADCIFA;
     
  /**************************************/
  /*            ADC Config              */
  /**************************************/

  adcifa_opt_t adcifa_opt = {
    .frequency = 100000,
    .reference_source = ADCIFA_REF1V,
    .sample_and_hold_disable  = TRUE,                // Disable Sample and Hold Time
    .single_sequencer_mode    = FALSE,               // Single Sequencer Mode 
    .free_running_mode_enable = FALSE,               // Free Running Mode 
    .sleep_mode_enable        = FALSE                // Sleep Mode
  };                             
  
  // Sequencer Configuration
  adcifa_sequencer_opt_t adcifa_sequence_opt = {
    .convnb               = 1,                       // Number of sequence
    .resolution           = ADCIFA_SRES_12B,         // Resolution selection
    .trigger_selection    = ADCIFA_TRGSEL_SOFT,      // Trigger selection
    .start_of_conversion  = ADCIFA_SOCB_ALLSEQ,      // Conversion Management
    .oversampling         = ADCIFA_CSWS_NOWSTATE,    // Oversampling Management - CSWS mode disabled
    .half_word_adjustment = ADCIFA_HWLA_NOADJ,       // Half word Adjustment
    .software_acknowledge = ADCIFA_SA_NO_EOS_SOFTACK // Software Acknowledge
  };
  
  // Conversions in the Sequencer Configuration  
  adcifa_sequencer_conversion_opt_t adcifa_sequence_conversion_opt[1] = 
    {
      {
	.channel_p = AVR32_ADCIFA_INP_TSENSE,   // Positive Channel
	.channel_n = AVR32_ADCIFA_INN_GNDANA,   // Negative Channel: Bug in software frame work. Numbering range [8-15] should be [0-7].
	.gain      = ADCIFA_SHG_1     // Gain of the conversion
      }                                      
    };
  
  /**************************************/
  /*            Backup ADC Register     */
  /**************************************/
  
   // Read ckdiv Register
  U32 ckdiv = adcifa->ckdiv;
  
   // Read CFG Register
  U32 cfg = adcifa->cfg;
    
  // Read Sequencer O configuration
  U32 seq_cfg = adcifa->seqcfg0;
  
  // Sequencer inputs selection
  U32 inpsel10 = AVR32_ADCIFA.inpsel10;
  U32 inpsel00 = AVR32_ADCIFA.inpsel00;
  U32 innsel10 = AVR32_ADCIFA.innsel10;
  U32 innsel00 = AVR32_ADCIFA.innsel00;  
  
  // Read S/H Gain O configuration
  U32 shg0 = AVR32_ADCIFA.shg0;
    
  /**************************************/
  /*             ADC Setup              */
  /**************************************/

  // Configure ADCIFA core
  adcifa_configure(adcifa,&adcifa_opt,g_pba_hz);
    
  // Configure ADCIFA sequencer 0
  adcifa_configure_sequencer(adcifa, 0, &adcifa_sequence_opt, adcifa_sequence_conversion_opt);

  // Start ADCIFA sequencer 0
  adcifa_start_sequencer(adcifa, 0);
  
  // Get Values from sequencer 0 when conversion is completed
  while (adcifa_get_values_from_sequencer(adcifa, 0, &adcifa_sequence_opt, adc_values)!=ADCIFA_STATUS_COMPLETED);
  // Software acknowledge End Of Sequence
  adcifa->scr |= (1 << AVR32_ADCIFA_SCR_SEOS0_OFFSET) & AVR32_ADCIFA_SCR_SEOS0_MASK;

  // Filter Only Consistency Values.
  if (adc_values[0] < ts_opt.ts_room) adc_values[0] = ts_opt.ts_room; 
  aref_recalc = (ts_opt.adc_hot-ts_opt.adc_room)*(adc_values[0]-ts_opt.ts_room);
  aref_recalc = aref_recalc/(ts_opt.ts_hot-ts_opt.ts_room);
  aref_recalc = ts_opt.adc_room + aref_recalc ;
  
  
  /**************************************/
  /*            Restore ADC Register    */
  /**************************************/
  // Restore CKDIV Register
  adcifa->ckdiv = ckdiv;
  
  // Restore CFG Register
  adcifa->cfg = cfg;
  
  // Restore Sequencer O configuration
  adcifa->seqcfg0 = seq_cfg;
  
  // Restore sequencer inputs selection 
  AVR32_ADCIFA.inpsel10 = inpsel10; 
  AVR32_ADCIFA.inpsel00 = inpsel00;
  AVR32_ADCIFA.innsel10 = innsel10;
  AVR32_ADCIFA.innsel00 = innsel00;
  
  // Restore S/H Gain0 Calibration
  AVR32_ADCIFA.shg0 = shg0;
  
  return aref_recalc;

}

void ts_get_calibration_data(ts_opt_t *ts_opt)
{
  ts_opt->ts_room  = (( *(volatile signed int *)(AVR32_FLASHC_FACTORY_PAGE_ADDRESS + AVR32_FLASHC_FROW_TSROOM_WORD)) &  AVR32_FLASHC_FROW_TSROOM_MASK) >> AVR32_FLASHC_FROW_TSROOM_OFFSET;
  ts_opt->ts_hot   = (( *(volatile signed int *)(AVR32_FLASHC_FACTORY_PAGE_ADDRESS + AVR32_FLASHC_FROW_TSHOT_WORD)) &  AVR32_FLASHC_FROW_TSHOT_MASK) >> AVR32_FLASHC_FROW_TSHOT_OFFSET;
  ts_opt->adc_room = (( *(volatile signed int *)(AVR32_FLASHC_FACTORY_PAGE_ADDRESS + AVR32_FLASHC_FROW_ADCROOM_WORD)) &  AVR32_FLASHC_FROW_ADCROOM_MASK) >> AVR32_FLASHC_FROW_ADCROOM_OFFSET;
  ts_opt->adc_hot  = (( *(volatile signed int *)(AVR32_FLASHC_FACTORY_PAGE_ADDRESS + AVR32_FLASHC_FROW_ADCHOT_WORD)) &  AVR32_FLASHC_FROW_ADCHOT_MASK) >> AVR32_FLASHC_FROW_ADCHOT_OFFSET;
}

void ts_init_timer(unsigned long pba_hz)
{
  volatile avr32_tc_t *tc = TC_INSTANCE;

  // Options for waveform genration.
  static const tc_waveform_opt_t WAVEFORM_OPT =
  {
    .channel  = TC_CHANNEL,                        // Channel selection.

    .bswtrg   = TC_EVT_EFFECT_NOOP,                // Software trigger effect on TIOB.
    .beevt    = TC_EVT_EFFECT_NOOP,                // External event effect on TIOB.
    .bcpc     = TC_EVT_EFFECT_NOOP,                // RC compare effect on TIOB.
    .bcpb     = TC_EVT_EFFECT_NOOP,                // RB compare effect on TIOB.

    .aswtrg   = TC_EVT_EFFECT_NOOP,                // Software trigger effect on TIOA.
    .aeevt    = TC_EVT_EFFECT_NOOP,                // External event effect on TIOA.
    .acpc     = TC_EVT_EFFECT_NOOP,                // RC compare effect on TIOA: toggle.
    .acpa     = TC_EVT_EFFECT_NOOP,                // RA compare effect on TIOA: toggle (other possibilities are none, set and clear).

    .wavsel   = TC_WAVEFORM_SEL_UP_MODE_RC_TRIGGER,// Waveform selection: Up mode with automatic trigger(reset) on RC compare.
    .enetrg   = FALSE,                             // External event trigger enable.
    .eevt     = 0,                                 // External event selection.
    .eevtedg  = TC_SEL_NO_EDGE,                    // External event edge selection.
    .cpcdis   = FALSE,                             // Counter disable when RC compare.
    .cpcstop  = FALSE,                             // Counter clock stopped with RC compare.

    .burst    = FALSE,                             // Burst signal selection.
    .clki     = FALSE,                             // Clock inversion.
    .tcclks   = TC_CLOCK_SOURCE_TC3                // Internal source clock 3, connected to fPBA / 8.
  };

  static const tc_interrupt_t TC_INTERRUPT =
  {
    .etrgs = 0,
    .ldrbs = 0,
    .ldras = 0,
    .cpcs  = 1,
    .cpbs  = 0,
    .cpas  = 0,
    .lovrs = 0,
    .covfs = 0
  };
  Disable_global_interrupt();

  // The INTC driver has to be used only for GNU GCC for AVR32.
#if defined (__GNUC__)
  // Initialize interrupt vectors.
  INTC_init_interrupts();

  // Register the RTC interrupt handler to the interrupt controller.
  INTC_register_interrupt(&ts_irq, TC_IRQ, AVR32_INTC_INT0);
#endif

  Enable_global_interrupt();
  
  // Store PBA Hz in global variable.
  g_pba_hz = pba_hz;
  
  // Initialize the timer/counter.
  tc_init_waveform(tc, &WAVEFORM_OPT);         // Initialize the timer/counter waveform.

  // Set the compare triggers.
  // Remember TC counter is 16-bits, so counting second is not possible with fPBA = 12 MHz.
  // We configure it to count ms.
  // We want: (1/(fPBA/8)) * RC = 0.001 s, hence RC = (fPBA/8) / 1000 = 1500 to get an interrupt every 1 ms.
  tc_write_rc(tc, TC_CHANNEL, (g_pba_hz / 8) / 1000); // Set RC value.

  tc_configure_interrupts(tc, TC_CHANNEL, &TC_INTERRUPT);

  // Start the timer/counter.
  tc_start(tc, TC_CHANNEL);                    // And start the timer/counter. 
  
}

void ts_start(ts_opt_t ts_opt)
{
  // Enable Tempsensor.
  scif_temperature_sensor_enable();
  
}

Bool ts_task(S32 input, S32 *output,ts_opt_t ts_opt)
{ 
  // Update the display on USART every second.
  if ((ts_start_read) && (!(tc_tick%1000)))
  {
    aref_recalc = ts_update_temperature(ts_opt);
    ts_start_read = 0;
    *output = ( ( input * (aref_recalc) ) / AREF_T );
    return TRUE;
  }  
  *output = ( ( input * (aref_recalc) ) / AREF_T );
  return FALSE;  
}