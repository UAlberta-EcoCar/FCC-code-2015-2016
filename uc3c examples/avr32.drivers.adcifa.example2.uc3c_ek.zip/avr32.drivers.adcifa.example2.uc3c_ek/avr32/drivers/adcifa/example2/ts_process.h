/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief Tempsensor Compensation Process for AVR UC3C.
 *
 *
 * - Compiler:           IAR EWAVR32 and GNU GCC for AVR UC3C
 * - Supported devices:  All AVR UC3C devices with an ADCIFA
 * - AppNote:
 *
 * \author               Atmel Corporation: http://www.atmel.com \n
 *                       Support and FAQ: http://support.atmel.no/
 *
 *****************************************************************************/

/*! \page License
 * Copyright (c) 2009 Atmel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an Atmel
 * AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 *
 */
#ifndef _TS_PROCESS_H_
#define _TS_PROCESS_H_

#include "compiler.h"

#include "conf_ts_process.h"

//! Parameters for the TS .
typedef struct
{
  //! TS Room.  
  S16 ts_room;
  
  //! TS Hot.
  S16 ts_hot;
  
  //! ADC room.
  S16 adc_room;

  //! ADC hot.
  S16 adc_hot;
  
} ts_opt_t;

/*! \brief Get TS Calibration Data. Mandatory to call if factory calibration data are wanted to be used.
 * If not called, Calibration Data should be set by the application.
 * \param *ts_opt Structure for the TS configuration 
 */
extern void ts_get_calibration_data( ts_opt_t * ts_opt);

/*! \brief TS Init Timer.
 * Initialize and Start a timer to call periodically (every sec) a temperature measurement.
 * \param pba_hz Peripheral Bus Clock Frequency used to configure the periodic timer.
 */                                  
extern void ts_init_timer(unsigned long pba_hz);

/*! \brief Start TS Task.
 * Start temperature sensor.
 * \param ts_opt Structure for the TS configuration
 */                                  
extern void ts_start(ts_opt_t ts_opt);

/*! \brief TS Task.
 * Compute ouptput with the algorithm. 
 * \param input Input ADC Value.
 * \param *output Output computed ADC Value.
 * \param ts_opt Structure for the TS configuration
 * \return BOOL  TRUE: a new temperature sensor has been computed. 
 *               FALSE: no new temperature sensor has been computed.
 */ 
extern Bool ts_task(S32 input, S32 *output,ts_opt_t ts_opt);

#endif  // _TS_PROCESS_H_